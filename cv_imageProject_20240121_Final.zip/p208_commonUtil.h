#pragma once

#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

class p208_commonUtil
{
public:
	static bool generateDigitsDataSetFromDigitsPNG(const string& fileName, Mat& X, Mat& y);
};

