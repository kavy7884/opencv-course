#pragma once
#include <iostream>
#include <vector>
#include <filesystem>

#include <opencv2/opencv.hpp>

using namespace std;
using std::string;
using std::vector;

using namespace cv;

class p201_commonUtil
{
public:
	static bool getFileList(const string filePath, vector<string>& fileList);
	static void lotteNumberGenerator(cv::Vec<uint8_t, 7>& lotteList);
	static bool generateRandomMatrix2D(Mat& buffer);
	static bool generateRandomMatrix3D(Mat& buffer);
};

