#pragma once

#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

class p206_commonUtil
{
public:
	static size_t splitContours(const string filePath, const size_t height, const size_t width, vector< pair<int, Mat> >& imageList);
	static uint8_t isJPEGwithEXIF(const string filePath);
};

