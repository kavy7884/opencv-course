#include "p208_commonUtil.h"
#include "p208_commonVariable.h"

bool p208_commonUtil::generateDigitsDataSetFromDigitsPNG(const string& fileName, Mat& X, Mat& y)
{
	bool ret = false;

    if (!haveImageReader(fileName))
    {
        cerr << "[" << __func__ << ":" << __LINE__ << "]\tThe file is not parsable for openCV:\t" << fileName << endl;
    }
    else if ((!X.empty()) || (!y.empty()))
    {
        cerr << "[" << __func__ << ":" << __LINE__ << "]\tWe need empty Mats X and y." << endl;
    }
    else
    {
        Mat image_buffer = imread(fileName);

        if ((image_buffer.data == nullptr) || (image_buffer.empty()) || (image_buffer.cols != SIZE_DIGITS_PNG_WIDTH) || (image_buffer.rows != SIZE_DIGITS_PNG_HEIGHT))
        {
            cerr << "[" << __func__ << ":" << __LINE__ << "]\tThe file is not readable for openCV:\t" << fileName << endl;
        }
        else
        {
            const int edge_length_sample = EDGE_LENGTH_SAMPLE;
            int buffer_width = 0, buffer_height = 0, h = 0, w = 0, index = 0, class_label = 0;
            Mat grayscale_buffer, boolean_buffer;
            MatIterator_<uint8_t> database_table_iterator;

            cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);
            threshold(grayscale_buffer, boolean_buffer, 127, 255, THRESH_BINARY);
            cout << "[" << __func__ << ":" << __LINE__ << "]\tThe profile of training set image:\tChannels = " << boolean_buffer.channels() << ", height = " << boolean_buffer.rows << ", width = " << boolean_buffer.cols << "." << endl;

            buffer_width = edge_length_sample * edge_length_sample;
            buffer_height = boolean_buffer.rows * boolean_buffer.cols / buffer_width;

            cout << "[" << __func__ << ":" << __LINE__ << "]\tThe expected size of rawData: rows = " << buffer_height << ". cols = " << buffer_width << "." << endl;
            X = Mat::zeros(buffer_height, buffer_width, CV_8UC1);
            y = Mat::zeros(buffer_height, 1, CV_32SC1);
            database_table_iterator = X.begin<uint8_t>();

            for (h = 0; h < boolean_buffer.rows; h += edge_length_sample)
            {
                for (w = 0; w < boolean_buffer.cols; w += edge_length_sample)
                {
                    Mat single_sample = boolean_buffer.rowRange(h, h + edge_length_sample).colRange(w, w + edge_length_sample);
                    Rect region = boundingRect(single_sample);
                    Mat real_sample = single_sample.rowRange(region.y, region.y + region.height).colRange(region.x, region.x + region.width);
                    Mat real_sample_resized;
                    resize(real_sample, real_sample_resized, Size(edge_length_sample, edge_length_sample));
                    MatIterator_<uint8_t> single_sample_iterator = real_sample_resized.begin<uint8_t>();
//#ifdef _DEBUG
#if 0
                    if (index % (buffer_height / 10) == 0)
                    {
                        imshow("First sample", real_sample_resized);
                        waitKey(0);
                        destroyAllWindows();
                    }
#endif
                    for (single_sample_iterator = real_sample_resized.begin<uint8_t>(); single_sample_iterator != real_sample_resized.end<uint8_t>(); ++single_sample_iterator)
                    {
                        *database_table_iterator = *single_sample_iterator;
                        database_table_iterator++;
                    }

                    index++;
                }
            }

            for (index = 0; index != X.rows; index += SIZE_EACH_DIGIT_GROUP)
            {
                int curr = 0;

                for (curr = class_label * SIZE_EACH_DIGIT_GROUP; curr < (class_label + 1) * SIZE_EACH_DIGIT_GROUP; ++curr)
                {
                    y.at<int32_t>(curr, 0) = class_label;
                }
                class_label++;
            }

//#ifdef _DEBUG
#if 0

            for (index = 0; index != X.rows; index += SIZE_EACH_DIGIT_GROUP)
            {
                Mat temp_buffer = X.row(index).reshape(0, 20);
                cout << "[" << __func__ << ":" << __LINE__ << "]\tThe label of image sample shown:\t" << static_cast<uint32_t>(y.at<uint8_t>(index, 0)) << "." << endl;
                imshow("First sample 2", temp_buffer);
                waitKey(0);
                destroyAllWindows();
            }
            imshow("training set", boolean_buffer);
            waitKey(0);
            destroyAllWindows();
#endif
            ret = true;
        }
    }

	return ret;
}