﻿// cv_imageProject.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include <iostream>
#include <fstream>
//#include <cmath>
#include <opencv2/opencv.hpp>
#include "p201_commonUtil.h"
#include "p203_commonUtil.h"
#include "p204_commonVariable.h"
#include "p204_commonUtil.h"
#include "p206_commonUtil.h"
#include "p206_commonVariable.h"
#include <TinyEXIF.h>
#include <opencv2/face/facerec.hpp>
#include "p208_commonUtil.h"

using namespace std;
using namespace cv;
using namespace TinyEXIF;
using namespace cv::face;
using namespace cv::ml;

int main(int argc, char** argv)
{
    unsigned int index = 0;
    cout << "The version of openCV detected:\t" << CV_VERSION << endl;
    cout << "Please assignn the index of test case:\t";
    cin >> index;

    cout << "The selected test case index = " << index << endl;

    switch (index)
    {
    case 0:
    {
        string testImagePath("");
        Mat testImage;
        cout << "Please assign the test image to be shown:\t";
        cin >> testImagePath;
        cout << "The selected test imagePath = " << testImagePath << endl;

        try
        {
            testImage = imread(testImagePath);
            imshow("Selected file image", testImage);
            waitKey(0);
            destroyAllWindows();
        }
        catch (exception e)
        {
            cerr << "Exception get:\t" << e.what() << endl;
        }

        break;
    }
    case 1:
    {
        string testDir("");
        cout << "Please assign the test dir to be listed:\t";
        cin >> testDir;

        bool ret = false;
        vector<string> fileList = vector<string>();
        ret = p201_commonUtil::getFileList(testDir, fileList);

        if (ret)
        {
            vector<string>::const_iterator it;

            for (it = fileList.begin(); it != fileList.end(); ++it)
            {
                cout << *it << endl;
            }

            cout << "Done. Totally " << fileList.size() << " files FOUND." << endl;
        }
        break;
    }
    case 2:
    {
        int i = 0;
        cv::Vec<uint8_t, 7> lotteVector = cv::Vec<uint8_t, 7>::zeros();
        p201_commonUtil::lotteNumberGenerator(lotteVector);

        cout << "The selected random number:\t";

        for (i = 0; i != lotteVector.channels; ++i)
        {
            cout << static_cast<uint32_t>(lotteVector[i]) << "\t";
        }

        cout << endl;
        break;
    }
    case 3:
    {
        bool result = false;
        int i = 0;
        int j = 0;
        int rows = 0;
        int cols = 0;
        Mat randomImage;
        cout << "Please assign the row size for random image:\t";
        cin >> rows;
        cout << "Please assign the column size for random image:\t";
        cin >> cols;

        randomImage = Mat(rows, cols, CV_64FC1);
        result = p201_commonUtil::generateRandomMatrix2D(randomImage);

        if (!result)
        {
            cerr << "The matrix can only be the 2D array with CV_64F." << endl;
        }
        else
        {
            cout << "The randomly generated matrix:" << endl;

            for (i = 0; i != randomImage.rows; ++i)
            {
                for (j = 0; j != randomImage.cols; ++j)
                {
                    cout << static_cast<uint16_t>(randomImage.at<double>(i, j)) << "\t";
                }
                cout << endl;
            }

            cout << "The generation of identity matrix:" << endl;

            Mat unitMatrix = randomImage * randomImage.inv();

            for (i = 0; i != unitMatrix.rows; ++i)
            {
                for (j = 0; j != unitMatrix.cols; ++j)
                {
                    cout << static_cast<uint16_t>(round(unitMatrix.at<double>(i, j))) << "\t"; //   #include <cmath>
                }
                cout << endl;
            }
        }
        break;
    }
    case 4:
    {
        bool result = false;
        int i = 0;
        int j = 0;
        int k = 0;
        int rows = 0;
        int cols = 0;
        Mat randomImage, scaledImage;
        cout << "Please assign the row size for random image:\t";
        cin >> rows;
        cout << "Please assign the column size for random image:\t";
        cin >> cols;

        randomImage = Mat(rows, cols, CV_64FC3);
        result = p201_commonUtil::generateRandomMatrix3D(randomImage);

        if (!result)
        {
            cerr << "The matrix can only be the 3D array with depth = 3. Now domension size = " << randomImage.channels() << endl;
        }
        else
        {
            randomImage.convertTo(scaledImage, CV_8U, 0.5, 1);

            for (i = 0; i != randomImage.rows; ++i)
            {
                for (j = 0; j != randomImage.cols; ++j)
                {
                    cout << "{";
                    for (k = 0; k != randomImage.channels(); ++k)
                    {
                        cout << randomImage.at< Vec<double, 3> >(i, j)[k] << " -> ";
                        cout << static_cast<uint16_t>(scaledImage.at< Vec<uint8_t, 3> >(i, j)[k]) << ", ";
                    }
                    cout << "}\t";
                }
                cout << endl;
            }
        }
        break;
    }
    case 5:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                int key;
                cout << "The Info of image:\theight = " << image_buffer.rows;
                cout << ", width = " << image_buffer.cols;
                cout << ", depth = " << image_buffer.channels();
                cout << ", dataType = " << image_buffer.depth() << "." << endl;
                imshow("Sample image", image_buffer);

                key = waitKey(0);
                if (key == 27)
                {
                    destroyAllWindows();
                }
            }
        }
        break;
    }
    case 6:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                string targetPath;
                cout << "Please assign the dir/path storing the cropped images, ended with \"\\\":\t";
                cin >> targetPath;

                int seg_line = static_cast<int>(image_buffer.cols / 2);
                time_t nowTime = time(nullptr);
                Mat image_buffer_left = image_buffer.colRange(0, seg_line);
                Mat image_buffer_right = image_buffer.colRange(seg_line, image_buffer.cols);

                string fileName_left = string(targetPath) + string("image_") + to_string(nowTime) + string("_left.jpg");
                string fileName_right = string(targetPath) + string("image_") + to_string(nowTime) + string("_right.jpg");

                vector<int> jpeg_compression_options;
                jpeg_compression_options.push_back(IMWRITE_JPEG_QUALITY);
                jpeg_compression_options.push_back(90);
                jpeg_compression_options.push_back(IMWRITE_JPEG_OPTIMIZE);
                jpeg_compression_options.push_back(1);

                imwrite(fileName_left, image_buffer_left, jpeg_compression_options);
                imwrite(fileName_right, image_buffer_right, jpeg_compression_options);

                cout << "Image cropping done to " << fileName_left << " and " << fileName_right << "." << endl;
            }
        }

        break;
    }
    case 7:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                uint8_t range;
                vector<Mat> channels;
                vector<Mat> fixed_channels;
                Mat image_buffer_updated;
                cout << "The ratio of blue-ray decreased (0 ~ 100):\t";
                cin >> range;
                range = 100 - (range % 100);

                split(image_buffer, channels);

                imshow("Original image", image_buffer);
                imshow("Blue-ray channel image", channels[0]);
                imshow("Green-ray channel image", channels[1]);
                imshow("Red-ray channel image", channels[2]);

                MatIterator_<uint8_t> it = channels[0].begin<uint8_t>();

                for (it = channels[0].begin<uint8_t>(); it != channels[0].end<uint8_t>(); ++it)
                {
                    *it = static_cast<uint8_t>(static_cast<double>(*it) * static_cast<double>(range) / 100.0);
                }

                fixed_channels.push_back(channels[0]);
                fixed_channels.push_back(channels[1]);
                fixed_channels.push_back(channels[2]);

                merge(fixed_channels, image_buffer_updated);

                imshow("Blue-ray reduced image", image_buffer_updated);

                waitKey(0);
                destroyAllWindows();
            }
        }
        break;
    }
    case 8:
    {
        int key, height = 0, width = 0;
        int total_sections = 17;
        cout << "Please assign the width of test image:\t";
        cin >> width;
        if (width % total_sections != 0)
        {
            cerr << "The width of test image MUST be the multiple of " << total_sections << endl;
        }
        else
        {
            cout << "Please assign the height of test image:\t";
            cin >> height;
            uint8_t current_b = 0, current_g = 255;
            Mat yellow_array = Mat(height, width, CV_8UC3, Scalar(current_b, current_g, 255));  //  R is 255 forever.
            imshow("Blank Yellow", yellow_array);

            key = waitKey(0);
            if (key == 27)
            {
                destroyAllWindows();
            }
            else
            {
                int column_section = 1;
                int delta = 16;
                bool lastTime = false;
                destroyAllWindows();

                while ((current_b < 255) && (current_g > 0))
                {
                    int row_index = 0, column_index = 0;
                    if (lastTime)
                    {
                        break;
                    }

                    if (current_b > 255 - delta)
                    {
                        current_b = 255;
                        lastTime = true;
                    }
                    else
                    {
                        current_b += delta;
                    }

                    if (current_g < delta)
                    {
                        current_g = 0;
                        lastTime = true;
                    }
                    else
                    {
                        current_g -= delta;
                    }
#ifdef  _DEBUG
                    cout << "column_section = " << column_section << endl;
#endif
                    for (row_index = 0; row_index != yellow_array.rows; ++row_index)
                    {
                        int column_start = static_cast<int>(column_section * yellow_array.cols / total_sections);
                        int column_end = static_cast<int>((column_section + 1) * yellow_array.cols / total_sections);
#ifdef  _DEBUG
                        if (row_index == 0)
                        {
                            cout << "column_start = " << column_start << ", column_end = " << column_end << endl;
                        }
#endif
                        for (column_index = column_start; column_index != column_end; ++column_index)
                        {
                            yellow_array.at< Vec<uint8_t, 3> >(row_index, column_index)[0] = current_b;
                            yellow_array.at< Vec<uint8_t, 3> >(row_index, column_index)[1] = current_g;
                        }

                    }
                    column_section++;
                }

                imshow("Hue evolution = " + to_string(total_sections), yellow_array);
                waitKey(0);
                destroyAllWindows();
            }
        }
        break;
    }
    case 9:
    {
        //
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                int32_t transp;
                vector<Mat> channels;
                vector<Mat> fixed_channels;
                string exportPath, exportDir;
                Mat transparency_channel;
                Mat image_buffer_updated;
                cout << "The ratio of Transparency (0 ~ 255):\t";
                cin >> transp;

                if ((transp < 0) || (transp > 255))
                {
                    cerr << "THe value is not valid:\t" << transp << "." << endl;
                }
                else
                {
                    split(image_buffer, channels);
                    transparency_channel = Mat(image_buffer.rows, image_buffer.cols, CV_8UC1, Scalar(transp));

                    fixed_channels.push_back(channels[0]);
                    fixed_channels.push_back(channels[1]);
                    fixed_channels.push_back(channels[2]);
                    fixed_channels.push_back(transparency_channel);

                    merge(fixed_channels, image_buffer_updated);

                    cout << "Please assign the directory for exporting the image file (end with \"\\\"):\t";
                    cin >> exportDir;
                    exportPath = exportDir + "Test_" + to_string(transp) + ".png";
                    imwrite(exportPath, image_buffer_updated);
                    cout << "Exporting the transparent image file to " << exportPath << " DONE." << endl;
                }
            }
        }
        //
        break;
    }
    case 10:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                Mat grayscaleImage = Mat::zeros(image_buffer.rows, image_buffer.cols, CV_8UC1);
                bool result = p203_commonUtil::bgrToGray(image_buffer, grayscaleImage);

                if (!result)
                {
                    cerr << "Grayscale image generation failed for " << fileName << endl;
                }
                else
                {
                    imshow("Grayscale of " + fileName, grayscaleImage);
                    waitKey(0);
                    destroyAllWindows();
                }
            }
        }
        break;
    }
    case 11:
    {
        string fileName;
        cout << "Please assign the full path of 1st image file to be read:\t";
        cin >> fileName;

        string gileName;
        cout << "Please assign the full path of 2nd image file to be read:\t";
        cin >> gileName;

        if ((!haveImageReader(fileName)) || (!haveImageReader(gileName)))
        {
            cerr << "At least one file is not parsable for openCV. Bye" << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);
            Mat jmage_buffer = imread(gileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()) || (jmage_buffer.data == nullptr) || (jmage_buffer.empty()))
            {
                cerr << "At least one file is not readable for openCV. Bye" << endl;
            }
            else
            {
                Mat mergedImage;
                bool ret = p203_commonUtil::mergeImage(image_buffer, jmage_buffer, mergedImage);

                if (!ret)
                {
                    cerr << "Merging image failed for " << fileName << " and " << gileName << endl;
                }
                else
                {
                    imshow("Merged Image", mergedImage);
                    waitKey(0);
                    destroyAllWindows();
                }
            }
        }
        break;
    }
    case 12:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                Mat negativeImage;
                bitwise_not(image_buffer, negativeImage);
                imshow("Negative Image", negativeImage);
                waitKey(0);
                destroyAllWindows();
            }
        }
        break;
    }
    case 13:
    {
        uint16_t r = 0, g = 0, b = 0, i = 0, j = 0;
        const int cols = 1, rows = 1;
        Mat pixel, hsv_array;

        cout << "Please assign the degree of Red (0 ~ 255):\t";
        cin >> r;
        cout << "Please assign the degree of Green (0 ~ 255):\t";
        cin >> g;
        cout << "Please assign the degree of Blue (0 ~ 255):\t";
        cin >> b;
        pixel = Mat(rows, cols, CV_8UC3, Scalar(b, g, r));
        cvtColor(pixel, hsv_array, COLOR_BGR2HSV_FULL);
        cout << "The info of HSV image: depth = " << hsv_array.depth() << ", channel size = " << hsv_array.channels() << endl;

        for (i = 0; i != hsv_array.rows; ++i)
        {
            for (j = 0; j != hsv_array.cols; ++j)
            {
                cout << "pixel item:\t{H = " << static_cast<uint16_t>(hsv_array.at< Vec<uint8_t, 3> >(i, j)[0]) * 360 / 256;
                cout << ", S = " << (static_cast<double>(hsv_array.at< Vec<uint8_t, 3> >(i, j)[1]) + 1) / 256.0 * 100.0 ;
                cout << "%, V = " << (static_cast<double>(hsv_array.at< Vec<uint8_t, 3> >(i, j)[2]) + 1) / 256.0 * 100.0 << "%}." << endl;
            }
        }
        break;
    }
    case 14:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                Mat grayscaleImage;
                cvtColor(image_buffer, grayscaleImage, COLOR_BGR2GRAY);
                cout << "The info of grayscaled image: depth = " << grayscaleImage.depth() << ", channel size = " << grayscaleImage.channels() << endl;

                imshow("Grayscale of " + fileName, grayscaleImage);
                waitKey(0);
                destroyAllWindows();
            }
        }
        break;
    }
    case 15:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                uint32_t angle;
                Mat rotated_image;
                cout << "Please assign the angle to be rotated counter-wise (90, 270, 180 otherwise):\t";
                cin >> angle;
                switch (angle)
                {
                case 90:
                    rotate(image_buffer, rotated_image, ROTATE_90_CLOCKWISE);
                    break;
                case 270:
                    rotate(image_buffer, rotated_image, ROTATE_90_COUNTERCLOCKWISE);
                    break;
                default:
                    rotate(image_buffer, rotated_image, ROTATE_180);
                    break;
                }
                imshow("Rotated image", rotated_image);
                waitKey(0);
                destroyAllWindows();
            }
        }
        break;
    }
    case 16:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                vector< Point_<float> > srcEdge = vector< Point_<float> >();
                vector< Point_<float> > dstEdge = vector< Point_<float> >();
                Mat mappingMatrix, calibrated_buffer;
                time_t nowTime = time(nullptr);
                string targetPath, fileName_calibrated;
                cout << "Please assign the dir/path storing the calibrated images, ended with \"\\\":\t";
                cin >> targetPath;

                fileName_calibrated = string(targetPath) + string("calibrated_") + to_string(nowTime) + string(".jpg");

                if ((image_buffer.cols != P204_DEFAULT_CARLABEL_SIZE_WIDTH) || (image_buffer.rows != P204_DEFAULT_CARLABEL_SIZE_HEIGHT))
                {
                    resize(image_buffer, image_buffer, Size(P204_DEFAULT_CARLABEL_SIZE_WIDTH, P204_DEFAULT_CARLABEL_SIZE_HEIGHT));
                }

                srcEdge.push_back(Point_<float>(30.0, 95.0));
                srcEdge.push_back(Point_<float>(86.0, 311.0));
                srcEdge.push_back(Point_<float>(450.0, 175.0));
                srcEdge.push_back(Point_<float>(426.0, 11.0));
                dstEdge.push_back(Point_<float>(56.0, 50.0));
                dstEdge.push_back(Point_<float>(56.0, 273.0));
                dstEdge.push_back(Point_<float>(444.0, 273.0));
                dstEdge.push_back(Point_<float>(444.0, 50.0));
                mappingMatrix = getPerspectiveTransform(srcEdge, dstEdge);
                warpPerspective(image_buffer, calibrated_buffer, mappingMatrix, Size(image_buffer.cols, image_buffer.rows));
                imshow("Skewed image: " + fileName, image_buffer);
                waitKey(0);
                imshow("Calibrated image of " + fileName, calibrated_buffer);
                waitKey(0);
                destroyAllWindows();
                imwrite(fileName_calibrated, calibrated_buffer);
                cout << "Exporting the Calibrated image file to " << fileName_calibrated << " DONE." << endl;
            }
        }
        break;
    }
    case 17:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                int i = 0, j = 0;
                Mat cropped_buffer, grayscale_buffer, boolean_buffer;
                time_t nowTime = time(nullptr);
                string targetPath, fileName_boolean;
                cout << "Please assign the dir/path storing the booleanized images, ended with \"\\\":\t";
                cin >> targetPath;

                fileName_boolean = string(targetPath) + string("boolean_") + to_string(nowTime) + string(".jpg");

                if ((image_buffer.cols != P204_DEFAULT_CARLABEL_SIZE_WIDTH) || (image_buffer.rows != P204_DEFAULT_CARLABEL_SIZE_HEIGHT))
                {
                    resize(image_buffer, image_buffer, Size(P204_DEFAULT_CARLABEL_SIZE_WIDTH, P204_DEFAULT_CARLABEL_SIZE_HEIGHT));
                }

                cropped_buffer = image_buffer.colRange(56, 444).rowRange(50, 273);
                cvtColor(cropped_buffer, grayscale_buffer, COLOR_BGR2GRAY);

                boolean_buffer = Mat::zeros(cropped_buffer.rows, cropped_buffer.cols, CV_8UC1);

                for (i = 0; i != grayscale_buffer.rows; ++i)
                {
                    for (j = 0; j != grayscale_buffer.cols; ++j)
                    {
                        if (grayscale_buffer.at<uint8_t>(i, j) <= 128)
                        {
                            boolean_buffer.at<uint8_t>(i, j) = 255;
                        }
                        else
                        {
                            boolean_buffer.at<uint8_t>(i, j) = 0;
                        }
                    }
                }

                imshow("Grayscale image", grayscale_buffer);
                waitKey(0);
                imshow("Boolean image", boolean_buffer);
                waitKey(0);
                destroyAllWindows();
                imwrite(fileName_boolean, boolean_buffer);
                cout << "Exporting the boolean image file to " << fileName_boolean << " DONE." << endl;
            }
        }
        break;
    }
    case 18:
    {
        string fileName;
        cout << "Please assign the full path of boolean image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                Mat eroded_buffer;
                uint16_t morph_size = 1;
                cout << "Please assign the size of kernel for eroding operations (1 or 2):\t";
                cin >> morph_size;

                if ((morph_size != 1) && (morph_size != 2))
                {
                    cerr << "Not supported morph_size generating the eroding/dilating kernel." << endl;
                }
                else
                {
                    Mat erode_kernel = getStructuringElement(MORPH_ELLIPSE, Size(2 * morph_size + 1, 2 * morph_size + 1));
                    uint16_t morph_type = 0;
                    cout << "Please assign the type of morphology operation ";
                    cout << "(0 = erode, 1 = dilate, 2 = open, 3 = close, 4 = tophat, 5 = blackhat, gredient otherwise):\t";
                    cin >> morph_type;

                    imshow("The original image", image_buffer);
                    waitKey(0);

                    switch (morph_type)
                    {
                    case 0 :
                        erode(image_buffer, eroded_buffer, erode_kernel);
                        imshow("The eroded image", eroded_buffer);
                        break;
                    case 1:
                        dilate(image_buffer, eroded_buffer, erode_kernel);
                        imshow("The dilated image", eroded_buffer);
                        break;
                    case 2:
                        morphologyEx(image_buffer, eroded_buffer, MORPH_OPEN, erode_kernel);
                        imshow("The opened image", eroded_buffer);
                        break;
                    case 3:
                        morphologyEx(image_buffer, eroded_buffer, MORPH_CLOSE, erode_kernel);
                        imshow("The closed image", eroded_buffer);
                        break;
                    case 4:
                        morphologyEx(image_buffer, eroded_buffer, MORPH_TOPHAT, erode_kernel);
                        imshow("The tophated image", eroded_buffer);
                        break;
                    case 5:
                        morphologyEx(image_buffer, eroded_buffer, MORPH_BLACKHAT, erode_kernel);
                        imshow("The blackhated image", eroded_buffer);
                        break;
                    default:
                        morphologyEx(image_buffer, eroded_buffer, MORPH_GRADIENT, erode_kernel);
                        imshow("The gradiented image", eroded_buffer);
                        break;
                    }   //  End of switch-case.

                    waitKey(0);
                    destroyAllWindows();
                }
            }
        }
        break;
    }
    case 19:
    {
        string fileName;
        cout << "Please assign the full path of image file to be analyzed:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                int i;
                vector<uint32_t> histogram = p204_commonUtil::grayscaleHistogram(image_buffer);
                ofstream targetFile;    //  #include <fstream>
                string targetPath, fileName_csv;
                time_t nowTime = time(nullptr);
                cout << "Please assign the dir/path storing the exported color distribution, ended with \"\\\":\t";
                cin >> targetPath;

                fileName_csv = string(targetPath) + string("histo_") + to_string(nowTime) + string(".csv");
                targetFile.open(fileName_csv);
                for (i = 0; i != histogram.size(); ++i)
                {
                    targetFile << "\"" << i << "\",\"" << histogram[i] << "\"" << endl;
                }
                targetFile.close();

                cout << "Histogram data generation to " << fileName_csv << " DONE." << endl;
            }
        }
        break;
    }
    case 20:
    {
        string fileName;
        cout << "Please assign the full path of calibrated image file to be read:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                int32_t kernel_size;
                Mat cropped_buffer, blur_buffer, grayscale_buffer, boolean_buffer;
                time_t nowTime = time(nullptr);
                string targetPath, fileName_boolean;
                cout << "Please assign the dir/path storing the (smoothed and) booleanized images, ended with \"\\\":\t";
                cin >> targetPath;

                fileName_boolean = string(targetPath) + string("smoothboolean_") + to_string(nowTime) + string(".jpg");

                cout << "Please assign the kernel size for bluring by median of pixels (3, 5, 7, 9, min(width, height) otherwise):\t";
                cin >> kernel_size;

                if ((kernel_size != 3) && (kernel_size != 5) && (kernel_size != 7) && (kernel_size != 9))
                {
                    if (image_buffer.cols > image_buffer.rows)
                    {
                        kernel_size = image_buffer.rows;
                    }
                    else
                    {
                        kernel_size = image_buffer.cols;
                    }

                    if (kernel_size % 2 == 0)
                    {
                        kernel_size--;
                    }
                }

                imshow("Original image", image_buffer);
                waitKey(0);
                cropped_buffer = image_buffer.colRange(56, 444).rowRange(50, 273);
                medianBlur(cropped_buffer, blur_buffer, kernel_size);
                imshow("Blurred image", blur_buffer);
                waitKey(0);
                cvtColor(blur_buffer, grayscale_buffer, COLOR_BGR2GRAY);
                threshold(grayscale_buffer, boolean_buffer, 128, 255, THRESH_BINARY_INV);
                imshow("Improved boolean image", boolean_buffer);
                waitKey(0);
                destroyAllWindows();
                imwrite(fileName_boolean, boolean_buffer);
                cout << "Exporting the (smoothed and ) booleanized image file to " << fileName_boolean << " DONE." << endl;
            }
        }
        break;
    }
    case 21:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read for edge detection:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                const int32_t kernel_size = 5;
                Mat grayscale_buffer, blur_buffer, edge_buffer;

                time_t nowTime = time(nullptr);
                string targetPath, fileName_edge;
                cout << "Please assign the dir/path storing the edge images, ended with \"\\\":\t";
                cin >> targetPath;

                fileName_edge = string(targetPath) + string("edge_") + to_string(nowTime) + string(".jpg");

                imshow("Original image", image_buffer);
                waitKey(0);
                cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);
                GaussianBlur(grayscale_buffer, blur_buffer, Size(kernel_size, kernel_size), 0.0, 0.0);
                imshow("Blurred image", blur_buffer);
                waitKey(0);
                Canny(blur_buffer, edge_buffer, 64, 36);
                imshow("Edged image", edge_buffer);
                waitKey(0);
                destroyAllWindows();

                cout << "The info of edged image:\tChannel size = " << edge_buffer.channels() << ", pixel depth = " << edge_buffer.depth() << "." << endl;
                imwrite(fileName_edge, edge_buffer);
                cout << "Exporting the boolean image file to " << fileName_edge << " DONE." << endl;
            }
        }
        break;
    }
    case 22:
    {
        string fileName;
        cout << "Please assign the full path of 1st image file to be read:\t";
        cin >> fileName;

        string gileName;
        cout << "Please assign the full path of 2nd image file to be read:\t";
        cin >> gileName;

        if ((!haveImageReader(fileName)) || (!haveImageReader(gileName)))
        {
            cerr << "At least one file is not parsable for openCV. Bye" << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);
            Mat jmage_buffer = imread(gileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()) || (jmage_buffer.data == nullptr) || (jmage_buffer.empty()))
            {
                cerr << "At least one file is not readable for openCV. Bye" << endl;
            }
            else
            {
                vector< pair<string, Mat> > imageList = vector< pair<string, Mat> >();
                int curr_item;
                vector<double> blur_measurement = vector<double>();
                imageList.push_back(make_pair(fileName, image_buffer));
                imageList.push_back(make_pair(gileName, jmage_buffer));

                for (curr_item = 0; curr_item != imageList.size(); ++curr_item)
                {
                    Mat grayscale_buffer, lap_buffer, mean_buffer, stdev_buffer;
                    double blur_value;
                    cvtColor(imageList[curr_item].second, grayscale_buffer, COLOR_BGR2GRAY);
                    Laplacian(grayscale_buffer, lap_buffer, CV_64F);
                    meanStdDev(lap_buffer, mean_buffer, stdev_buffer);
                    blur_value = stdev_buffer.at<double>(0, 0);

                    cout << "The degree of blur:\t" << blur_value << " for " << imageList[curr_item].first << "." << endl;
                    blur_measurement.push_back(blur_value);
                }

                if (blur_measurement[0] > blur_measurement[1])
                {
                    cout << "The file is more blur:\t" << imageList[1].first << "." << endl;
                    imshow("Original image", imageList[1].second);
                    waitKey(0);
                }
                else if (blur_measurement[0] < blur_measurement[1])
                {
                    cout << "The file is more blur:\t" << imageList[0].first << "." << endl;
                    imshow("Original image", imageList[0].second);
                    waitKey(0);
                }
                else
                {
                    cout << "We cannot identify which file is more blur." << endl;
                }
            }
        }
        break;
    }
    case 23:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read for contour detection:\t";
        cin >> fileName;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                time_t nowTime = time(nullptr);
                string targetPath, fileName_contour;
                vector< vector< Point_<int> > > contours;
                vector< Vec<int, 4> > hierarchy;
                char filled;
                Mat grayscale_buffer, boolean_buffer;
                Mat dst_buffer = Mat::zeros(image_buffer.rows, image_buffer.cols, CV_8UC3);
#ifdef _DEBUG
                vector< vector< Point_<int> > >::const_iterator contours_set_pointer;
#endif
                cout << "Please assign the dir/path storing the contour images, ended with \"\\\":\t";
                cin >> targetPath;
                cout << "Do you want the detected contour to be filled with predefined color ? (Y for filled. Otherwise draw with thin line)\t";
                cin >> filled;

                cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);
                threshold(grayscale_buffer, boolean_buffer, 128, 255, THRESH_BINARY_INV);

                fileName_contour = string(targetPath) + string("contour_") + to_string(nowTime) + string(".jpg");
                findContours(boolean_buffer, contours, hierarchy, RETR_LIST, CHAIN_APPROX_NONE);
                imshow("Original image", image_buffer);
                waitKey(0);
                if ((filled == 'Y') || (filled == 'y'))
                {
                    drawContours(dst_buffer, contours, -1, Scalar(255.0, 0.0, 255.0), FILLED, LINE_AA, hierarchy);
                }
                else
                {
                    drawContours(dst_buffer, contours, -1, Scalar(255.0, 0.0, 255.0), 1, LINE_AA, hierarchy);
                }
#ifdef _DEBUG
                for (contours_set_pointer = contours.begin(); contours_set_pointer != contours.end(); ++contours_set_pointer)
                {
                    vector< Point_<int> >::const_iterator contour_point_pointer = contours_set_pointer->begin();
                    for (contour_point_pointer = contours_set_pointer->begin(); contour_point_pointer != contours_set_pointer->end(); ++contour_point_pointer)
                    {
                        cout << "The point:\t(" << contour_point_pointer->x << ", " << contour_point_pointer->y << ")" << endl;
                    }
                }
#endif
                imshow("Contours image", dst_buffer);
                waitKey(0);
                imwrite(fileName_contour, dst_buffer);
                cout << "Exporting the contour image file to " << fileName_contour << " DONE." << endl;
            }
        }
        break;
    }
    case 24:
    {
        string fileName;
        cout << "Please assign the full path of image file to be read for contour separation:\t";
        cin >> fileName;

        vector< pair<int, Mat> > imageList = vector< pair<int, Mat> >();
        size_t image_size = p206_commonUtil::splitContours(fileName, 28, 28, imageList);

        if (image_size > 0)
        {
            for (pair<int, Mat> image : imageList)
            {
                imshow("Extracted component", image.second);
                waitKey(0);
                destroyAllWindows();
            }
        }
        break;
    }
    case 25:
    {
        uint8_t ret = ERRNO_EXIF_OK;
        string fileName;
        cout << "Please assign the full path of image file for extracting the EXIF metadata:\t";
        cin >> fileName;

        ret = p206_commonUtil::isJPEGwithEXIF(fileName);

        if (ret == ERRNO_EXIF_OK)
        {
            cout << "The file is EXIF-embedded JPEG file:\t" << fileName << endl;
        }
        break;
    }
    case 26:
    {
        uint8_t ret = ERRNO_EXIF_OK;
        string fileName;
        cout << "Please assign the full path of image file for extracting the EXIF metadata:\t";
        cin >> fileName;

        ret = p206_commonUtil::isJPEGwithEXIF(fileName);

        if (ret != ERRNO_EXIF_OK)
        {
            //  DO NOTHING.
        }
        else
        {
            ifstream binaryStream(fileName, ifstream::binary);

            EXIFInfo imageEXIF = EXIFInfo(binaryStream);

            if (imageEXIF.Fields)
            {
                cout << "The resolution:\t" << imageEXIF.ImageWidth << " x " << imageEXIF.ImageHeight << "." << endl;
                cout << "The camera model:\t" << imageEXIF.Make << " " << imageEXIF.Model << "." << endl;
                
                if (imageEXIF.GeoLocation.hasLatLon())
                {
                    cout << "The GEO Location:\t" << imageEXIF.GeoLocation.Latitude << "," << imageEXIF.GeoLocation.Longitude << "." << endl;
                    cout << "The openstreetmapURL:\t";
                    cout << "https://www.openstreetmap.org/search?query=" << imageEXIF.GeoLocation.Latitude << "%2C" << imageEXIF.GeoLocation.Longitude;
                    cout << endl;
                }
                else
                {
                    cout << "The GEO Location is NOT available." << endl;
                }
            }
            binaryStream.close();
        }
        break;
    }
    case 27:
    {
        const int default_cam_size = 10;
        int cam_size = 0, i = 0;
        vector<VideoCapture> captureObject_list = vector<VideoCapture>();
        vector<VideoCapture>::iterator it;
        cout << "Please define the max size of cameras to be available in this host:\t";
        cin >> cam_size;

        if (cam_size <= 0)
        {
            cam_size = default_cam_size;
        }

        for (i = 0; i != cam_size; ++i)
        {
            VideoCapture captureObject = VideoCapture(i, CAP_ANY);

            if (captureObject.isOpened())
            {
                cout << "[index = " << i << "]\tCamera FOUND. backend = " << captureObject.getBackendName() << "." << endl;
                captureObject_list.push_back(captureObject);    //  Copy the object to vector.
            }
            else
            {
                cout << "[index = " << i << "]\tCamera NOT FOUND." << endl;
            }
        }

        cout << "OK. Totally " << captureObject_list.size() << " cameras FOUND in this host." << endl;

        for (it = captureObject_list.begin(); it != captureObject_list.end(); ++it)
        {
            it->release();
        }
        break;
    }
    case 28:
    {
        string fileName;
        cout << "Please assign the full path of video file for extracting the profile:\t";
        cin >> fileName;

        VideoCapture videoObject = VideoCapture(fileName, CAP_ANY);

        if (videoObject.isOpened())
        {
            double w = videoObject.get(CAP_PROP_FRAME_WIDTH);
            double h = videoObject.get(CAP_PROP_FRAME_HEIGHT);
            double c = videoObject.get(CAP_PROP_FRAME_COUNT);
            double fps = videoObject.get(CAP_PROP_FPS);
            double frame_time = 1000 / fps;
            uint32_t total_seconds = static_cast<uint32_t>(c / fps);

            cout << "The fileName is opened as Video:\t" << fileName << ":" << endl;
            cout << "\tThe backend decoding the Video:\t" << videoObject.getBackendName() << "." << endl;
            cout << "\tThe resolution of Video:\t" << w << " x " << h << " pixels." << endl;
            cout << "\tThe length of Video:\t" << total_seconds / 60 << " mins and " << total_seconds % 60 << " secs. Each frame spent " << frame_time << " ms." << endl;
        }
        else
        {
            cerr << "The specified file cannot be opened as Video:\t" << fileName << "." << endl;
        }
        videoObject.release();
        break;
    }
    case 29:
    {
        string fileName;
        cout << "Please assign the full path of video file for extracting the frame:\t";
        cin >> fileName;

        VideoCapture videoObject = VideoCapture(fileName, CAP_ANY);

        if (videoObject.isOpened())
        {
            double c = videoObject.get(CAP_PROP_FRAME_COUNT);
            double fps = videoObject.get(CAP_PROP_FPS);
            uint32_t total_seconds = static_cast<uint32_t>(c / fps);
            uint32_t location = 0;
            Mat current_frame;

            cout << "Please assign the location of frame to be extracted (0s to "<< total_seconds - 1 << "s):\t";
            cin >> location;

            if (location >= total_seconds)
            {
                cerr << "Oops! Invalid location of Video:\t" << location << "s." << endl;
            }
            else
            {
                videoObject.set(CAP_PROP_POS_FRAMES, location);

                if (!videoObject.read(current_frame))
                {
                    cerr << "Oops! Error extracing the frame from the location of Video!" << endl;
                }
                else
                {
                    imshow("The specified frame", current_frame);
                    waitKey(0);
                    videoObject.release();
                    destroyAllWindows();
                }
            }
        }
        else
        {
            cerr << "The specified file cannot be opened as Video:\t" << fileName << "." << endl;
        }
        videoObject.release();
        break;
    }
    case 30:
    {
        string fileName;
        uint32_t frame_time_multiplier = 1;
        cout << "Please assign the full path of video file for play:\t";
        cin >> fileName;

        VideoCapture videoObject = VideoCapture(fileName, CAP_ANY);
        bool result = false;
        uint32_t fps_rate = 0;

        if (videoObject.isOpened())
        {
            cout << "Please assign the speed playing the video (2 = 0.5 speed, 4 = 0.25 speed, normal speed otherwise):\t";
            cin >> frame_time_multiplier;

            if ((frame_time_multiplier != 2) && (frame_time_multiplier != 4))
            {
                frame_time_multiplier = 1;
            }

            fps_rate = static_cast<uint32_t>(videoObject.get(CAP_PROP_FPS));
        }

        while (videoObject.isOpened())
        {
            Mat current_frame;
            int current_key;
            result = videoObject.read(current_frame);

            if (!result)
            {
                cerr << "Oops! Error extracing the frame from the location of Video!" << endl;
                break;
            }
            else
            {
                imshow("Playing now.", current_frame);
                current_key = waitKey(1000 * frame_time_multiplier / fps_rate);

                if (current_key == 0x1b)
                {
                    break;
                }
            }
        }
        destroyAllWindows();
        videoObject.release();
        break;
    }
    case 31:
    {
        VideoCapture videoObject;
        VideoWriter writerObject;
        int apiPreference = CAP_FFMPEG;
        int fourcc = VideoWriter::fourcc('X', 'V', 'I', 'D');
        time_t nowTime = time(nullptr);
        double fps_rate = 0.0;
        Size frameSize;
        string fileName, targetDir, targetName;
        cout << "Please assign the full path of video file for cropping:\t";
        cin >> fileName;
        cout << "Please assign the directory for exporting the image file (end with \"\\\"):\t";
        cin >> targetDir;

        targetName = string(targetDir) + string("croppedVideo_") + to_string(nowTime) + string(".avi");
        videoObject = VideoCapture(fileName, CAP_ANY);
        fps_rate = videoObject.get(CAP_PROP_FPS);
        frameSize = Size(static_cast<int32_t>(videoObject.get(CAP_PROP_FRAME_WIDTH)), static_cast<int32_t>(videoObject.get(CAP_PROP_FRAME_HEIGHT)));
        writerObject = VideoWriter(targetName, apiPreference, fourcc, fps_rate, frameSize);

        if ((videoObject.isOpened()) && (writerObject.isOpened()))
        {
            double c = videoObject.get(CAP_PROP_FRAME_COUNT);
            uint32_t total_seconds = static_cast<uint32_t>(c / fps_rate);
            uint32_t location = 0, until = 0, start_frame = 0, end_frame = 0, copy_iters = 0, idx = 0;

            cout << "FPS Rate = " << fps_rate << "." << endl;

            cout << "Please assign the start frame to be copied (0s to " << total_seconds - 1 << "s):\t";
            cin >> location;

            if (location >= total_seconds)
            {
                location = 0;
            }

            cout << "Please assign the end frame to be copied (" << location << "s to " << total_seconds - 1 << "s):\t";
            cin >> until;

            if ((until >= total_seconds) || (until < location))
            {
                until = total_seconds - 1;
            }

            start_frame = static_cast<uint32_t>(static_cast<double>(location) * fps_rate);
            end_frame = static_cast<uint32_t>(static_cast<double>(until) * fps_rate);
            copy_iters = end_frame - start_frame;

            cout << "start_frame = " << start_frame << ", end_frame = " << end_frame << ", copy_iters = " << copy_iters << "." << endl;

            videoObject.set(CAP_PROP_POS_FRAMES, start_frame);

            for (idx = 0; idx != copy_iters; ++idx)
            {
                Mat current_frame;
                bool rett = videoObject.read(current_frame);

                if (rett)
                {
                    writerObject.write(current_frame);
                }
                else
                {
                    break;
                }
            }

            cout << "Totally " << copy_iters << " frames copied to " << targetName << "." << endl;

        }
        else
        {
            cerr << "At least one video I/O stream CANNOT be created." << endl;
        }
        videoObject.release();
        writerObject.release();
        break;
    }
    case 32:
    {
        string fileName, modelPath;
        cout << "Please assign the full path of image file for face detection:\t";
        cin >> fileName;
        cout << "Please assign the full path for importing the pre-defined face detection model (end with *.xml):\t";
        cin >> modelPath;    //  The pre-defined model for cascadeclassifier is located at:  build\etc\haarcascades\

        CascadeClassifier x = CascadeClassifier();
        
        if (!x.load(modelPath))
        {
            cerr << "Loading face detection model from " << modelPath << " FAILED." << endl;
        }
        else
        {
            if (!haveImageReader(fileName))
            {
                cerr << "The file is not parsable for openCV:\t" << fileName << endl;
            }
            else
            {
                Mat image_buffer = imread(fileName);

                if ((image_buffer.data == nullptr) || (image_buffer.empty()))
                {
                    cerr << "The file is not readable for openCV:\t" << fileName << endl;
                }
                else
                {
                    Mat grayscale_buffer;
                    vector<Rect> faces = vector<Rect>();
                    vector<Rect>::const_iterator it;
                    double scaleFactor = 1.02;
                    int minNeighbors = 3;
                    int size_ceiling = 40;

                    cout << "[Tuning the face recognition]\tPlease define the scaleFactor:\t";
                    cin >> scaleFactor;
                    cout << "[Tuning the face recognition]\tPlease define the minNeighbors:\t";
                    cin >> minNeighbors;
                    cout << "[Tuning the face recognition]\tPlease define the minimum width of Rect considered as NOISE:\t";
                    cin >> size_ceiling;

                    if (scaleFactor < 1.02)
                    {
                        scaleFactor = 1.02;
                    }

                    if (minNeighbors <= 1)
                    {
                        minNeighbors = 1;
                    }

                    if (size_ceiling < 40)
                    {
                        size_ceiling = 40;
                    }

                    cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);
                    x.detectMultiScale(grayscale_buffer, faces, scaleFactor, minNeighbors, 0, Size(size_ceiling, size_ceiling), 
                        Size(image_buffer.cols / 3, image_buffer.cols / 3));

                    for (it = faces.begin(); it != faces.end(); ++it)
                    {
                        rectangle(image_buffer, *it, Scalar(255, 0, 255), 2, LINE_AA);
                    }
                    imshow("finding faces!", image_buffer);
                    waitKey(0);
                    destroyAllWindows();
                    cout << "Totally " << faces.size() << " faced detected. Bye" << endl;
                }
            }
        }

        break;
    }
    case 33:
    {
        int i = 0;
        bool dataCollected = true;
        string sourceDir0, sourceDir1;
        vector<string> fileList0 = vector<string>();
        vector<string> fileList1 = vector<string>();

        vector<string> sourceDirs = { sourceDir0 , sourceDir1 };
        vector< vector<string> > fileLists = { fileList0, fileList1 };
        vector<Mat> trainingSample = vector<Mat>();
        vector<int> trainingLabel = vector<int>();

        for (i = 0; i != sourceDirs.size(); ++i)
        {
            bool ret;
            cout << "Please assign the " << i << "-th directory for exporting the image file (end with \"\\\"):\t";
            cin >> sourceDirs[i];
            ret = p201_commonUtil::getFileList(sourceDirs[i], fileLists[i]);

            if (!ret)
            {
                cerr << "Getting sample list failed from " << sourceDirs[i] << ".Bye~" << endl;
                dataCollected = false;
                break;
            }
            else
            {
                vector<string>::const_iterator it;
                for (it = fileLists[i].begin(); it != fileLists[i].end(); ++it)
                {
                    cout << "Reading raw data from " << *it << endl;

                    if (!haveImageReader(*it))
                    {
                        cerr << "The file is not parsable for openCV:\t" << *it << endl;
                    }
                    else
                    {
                        Mat image_buffer = imread(*it);

                        if ((image_buffer.data == nullptr) || (image_buffer.empty()))
                        {
                            cerr << "The file is not readable for openCV:\t" << *it << endl;
                        }
                        else
                        {
                            Mat grayscale_buffer;
                            cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);
                            trainingSample.push_back(grayscale_buffer);
                            trainingLabel.push_back(i);
                        }
                    }
                }
            }
        }

        if (dataCollected)
        {
            int j = 0;
            string modelDir, modelPath;
            time_t nowTime = time(nullptr);
#ifdef _DEBUG
            for (j = 0; j != trainingLabel.size(); ++j)
            {
                cout << trainingLabel[j] << " -> ";
            }
            cout << endl;
#endif // _DEBUG

            cout << "Please assign the directory saving the trained face recognition model (end with \"\\\"):\t";
            cin >> modelDir;

            modelPath = string(modelDir) + string("facemodel_") + to_string(nowTime) + string(".xml");

            Ptr<LBPHFaceRecognizer> face_detector_model = LBPHFaceRecognizer::create();
            face_detector_model->train(trainingSample, trainingLabel);
            face_detector_model->write(modelPath);
            cout << "FACE Prediction model had been generated and saved to " << modelPath << "." << endl;
        }
        else
        {
            cerr << "FACE Prediction model generation failed owing to the data collection failed." << endl;
        }
        
        break;
    }
    case 34:
    {
        string fileName, modelPath;
        cout << "Please assign the full path of image file for face detection:\t";
        cin >> fileName;
        cout << "Please assign the full path for importing the pre-defined face recognition model (end with *.modelFile):\t";
        cin >> modelPath;

        if (!haveImageReader(fileName))
        {
            cerr << "The file is not parsable for openCV:\t" << fileName << endl;
        }
        else
        {
            Mat image_buffer = imread(fileName);

            if ((image_buffer.data == nullptr) || (image_buffer.empty()))
            {
                cerr << "The file is not readable for openCV:\t" << fileName << endl;
            }
            else
            {
                Ptr<LBPHFaceRecognizer> face_detector_model;
                Mat grayscale_buffer;
                int prediction_label = 0;
                double prediction_confidence = 0.0;
                cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);

                face_detector_model = LBPHFaceRecognizer::create();
                face_detector_model->read(modelPath);

                face_detector_model->predict(grayscale_buffer, prediction_label, prediction_confidence);

                cout << "My prediction:\tClass " << prediction_label << ". Confidence level = " << prediction_confidence << "." << endl;
            }
        }

        break;
    }
    case 35:
    {
        string fileName;
        Mat rawData, y;
        bool res = false;
        cout << "Please assign the full path of image file for training of the digit detection model:\t";
        cin >> fileName;

        res = p208_commonUtil::generateDigitsDataSetFromDigitsPNG(fileName, rawData, y);

        if (!res)
        {
            cerr << "Generating the data sample failed from " << fileName << ". Bye" << endl;
        }
        else
        {
            Mat X;
            Ptr<KNearest> ocr_model;
            Ptr<TrainData> ocr_trainingset;
            string targetPath, fileName_model;
            time_t nowTime = time(nullptr);

            rawData.convertTo(X, CV_32FC1);
            cout << "Profile of X:\t" << X.rows << " x " << X.cols << ". The type = " << X.type() << endl;
            cout << "Profile of y:\t" << y.rows << " x " << y.cols << endl;

            cout << "Please assign the dir/path exporting the OCR model trained, ended with \"\\\":\t";
            cin >> targetPath;

            fileName_model = string(targetPath) + string("ocrmodel_") + to_string(nowTime) + string(".xml");

            ocr_trainingset = TrainData::create(X, ROW_SAMPLE, y);

            ocr_model = KNearest::create();
            ocr_model->train(ocr_trainingset);
            ocr_model->save(fileName_model);
            ocr_model->clear();
            cout << "Saving the OCR model to " << fileName_model << " DONE. Bye~" << endl;
        }
        break;
    }
    case 36:
    {
        string fileName, fileName_model;
        cout << "Please assign the full path of image file for loading OCR model, ended with \".xml\":\t";
        cin >> fileName_model;

        cout << "Please assign the full path of image file to be read for contour separation:\t";
        cin >> fileName;

        vector< pair<int, Mat> > imageList = vector< pair<int, Mat> >();
        size_t image_size = p206_commonUtil::splitContours(fileName, 20, 20, imageList);

        if (image_size >= 7)
        {
            Ptr<KNearest> ocr_model = KNearest::create();
            int index = 3;
            ocr_model = KNearest::load(fileName_model);

            for (index = 3; index != 7; ++index)
            {
                Mat current_number_image, current_erode_image, current_number_row, current_number_prediction;
                Mat erode_kernel = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
                dilate(imageList[index].second, current_erode_image, erode_kernel);
                imshow("Sample:", current_erode_image);
                waitKey(0);
                destroyAllWindows();
                current_erode_image.convertTo(current_number_image, CV_32FC1);
                current_number_row = current_number_image.reshape(0, 1);
                cout << "The size of current_number_row:\t" << current_number_row.rows << " x " << current_number_row.cols << ". The type = " << current_number_row.type() << endl;

                ocr_model->findNearest(current_number_row, 9, current_number_prediction);
                cout << "The size of current_number_prediction:\t" << current_number_prediction.rows << " x " << current_number_prediction.cols << ". The type = " << current_number_prediction.type() << endl;
                cout << "The prediction result:\t" << current_number_prediction.at<float>(0, 0) << endl;
            }
            
            ocr_model->clear();
        }

        break;
    }
    case 37:
    {
        int k = 10;
        string fileName;
        Mat rawData, y;
        bool res = false;
        cout << "Please assign the full path of image file for training of the digit detection model:\t";
        cin >> fileName;

        res = p208_commonUtil::generateDigitsDataSetFromDigitsPNG(fileName, rawData, y);

        if (!res)
        {
            cerr << "Generating the data sample failed from " << fileName << ". Bye" << endl;
        }
        else
        {
            int i = 0;
            string targetPath, fileName_csv;
            time_t nowTime = time(nullptr);
            Mat X, bestLabels, centeroids;
            double compactness = 0.0;
            ofstream targetFile;    //  #include <fstream>
            rawData.convertTo(X, CV_32FC1);
            cout << "Please assign the proper value K (5, 15, or 10 otherwise):\t";
            cin >> k;

            if ((k != 15) && (k != 5))
            {
                k = 10;
            }

            //  https://docs.opencv.org/4.x/d9/d5d/classcv_1_1TermCriteria.html
            //  https://docs.opencv.org/4.x/d5/d38/group__core__cluster.html
            compactness = kmeans(X, k, bestLabels, TermCriteria(TermCriteria::Type::EPS + TermCriteria::Type::MAX_ITER, 10, 1.0), 3, KMEANS_PP_CENTERS, centeroids);
            cout << "Please assign the dir/path storing the exported clustering distribution, ended with \"\\\":\t";
            cin >> targetPath;
            fileName_csv = string(targetPath) + string("clsteringdistro_") + to_string(nowTime) + string(".csv");

            targetFile.open(fileName_csv);

            targetFile << "\"SEQ\",\"Real Number\",\"Predicted Class-Label\"" << endl;

            for (i = 0; i < y.rows; ++i)
            {
                targetFile << "\"" << i + 1 << "\",\"" << y.at<int32_t>(i, 0) << "\",\"" << bestLabels.at<int32_t>(i, 0) << "\"" << endl;
            }

            targetFile.close();

            cout << "clustering distribution generated to " << fileName_csv << " DONE." << endl;
        }
        break;
    }
    case 1000:
    {
        //  Additional: Testing the overflow behaviour of cv::addWeighted()
        uint16_t r = 0, g = 0, b = 0, R = 0, G = 0, B = 0;
        double alpha = 1.0, beta = 1.0, gamma = 0.0;
        MatIterator_< Vec<uint8_t, 3> > it;

        const int cols = 1, rows = 1;
        Mat pixel, qixel, added_array;

        cout << "Please assign the degree of Red for matrix 1 (0 ~ 255):\t";
        cin >> r;
        cout << "Please assign the degree of Green for matrix 1 (0 ~ 255):\t";
        cin >> g;
        cout << "Please assign the degree of Blue for matrix 1 (0 ~ 255):\t";
        cin >> b;
        pixel = Mat(rows, cols, CV_8UC3, Scalar(b, g, r));

        cout << "Please assign the degree of Red for matrix 2 (0 ~ 255):\t";
        cin >> R;
        cout << "Please assign the degree of Green for matrix 2 (0 ~ 255):\t";
        cin >> G;
        cout << "Please assign the degree of Blue for matrix 2 (0 ~ 255):\t";
        cin >> B;
        qixel = Mat(rows, cols, CV_8UC3, Scalar(B, G, R));

        cout << "Please assign the degree of alpha factor float value):\t";
        cin >> alpha;
        cout << "Please assign the degree of beta factor float value):\t";
        cin >> beta;
        cout << "Please assign the degree of gamma factor float value):\t";
        cin >> gamma;

        addWeighted(pixel, alpha, qixel, beta, gamma, added_array);

        for (it = added_array.begin< Vec<uint8_t, 3> >(); it != added_array.end< Vec<uint8_t, 3> >(); ++it)
        {
            cout << "The added channel:\t" << static_cast<uint32_t>((*it)[0]) << ", " << static_cast<uint32_t>((*it)[1]) << ", " << static_cast<uint32_t>((*it)[2]) << ", " << endl;
        }

        break;
    }
    default:
        break;
    }

    return 0;
}

// 執行程式: Ctrl + F5 或 [偵錯] > [啟動但不偵錯] 功能表
// 偵錯程式: F5 或 [偵錯] > [啟動偵錯] 功能表

// 開始使用的提示: 
//   1. 使用 [方案總管] 視窗，新增/管理檔案
//   2. 使用 [Team Explorer] 視窗，連線到原始檔控制
//   3. 使用 [輸出] 視窗，參閱組建輸出與其他訊息
//   4. 使用 [錯誤清單] 視窗，檢視錯誤
//   5. 前往 [專案] > [新增項目]，建立新的程式碼檔案，或是前往 [專案] > [新增現有項目]，將現有程式碼檔案新增至專案
//   6. 之後要再次開啟此專案時，請前往 [檔案] > [開啟] > [專案]，然後選取 .sln 檔案
