#pragma once

#include <opencv2/opencv.hpp>

using namespace std;
using std::string;
using std::vector;

using namespace cv;

class p204_commonUtil
{
public:
	static vector<uint32_t> grayscaleHistogram(const Mat& inputImage);
};

