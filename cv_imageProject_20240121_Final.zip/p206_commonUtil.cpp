#include "p206_commonUtil.h"
#include "p206_commonVariable.h"
#include <fstream>
#include <iomanip>

bool comparePairs(pair<int, Mat> a, pair<int, Mat> b)
{
	return a.first < b.first;
}

size_t p206_commonUtil::splitContours(const string filePath, const size_t height, const size_t width, vector< pair<int, Mat> >& imageList)
{
	if (!haveImageReader(filePath))
	{
		cerr << "[" << __func__ << ":" << __LINE__ << "]\tThe file is not parsable for openCV:\t" << filePath << endl;
	}
	else
	{
		Mat image_buffer = imread(filePath);

		if ((image_buffer.data == nullptr) || (image_buffer.empty()))
		{
			cerr << "[" << __func__ << ":" << __LINE__ << "]\tThe file is not readable for openCV:\t" << filePath << endl;
		}
		else
		{
			vector< vector< Point_<int> > > contours;
			vector< Vec<int, 4> > hierarchy;
			Mat grayscale_buffer, boolean_buffer;
			cvtColor(image_buffer, grayscale_buffer, COLOR_BGR2GRAY);
			threshold(grayscale_buffer, boolean_buffer, 128, 255, THRESH_BINARY_INV);

			findContours(boolean_buffer, contours, hierarchy, RETR_LIST, CHAIN_APPROX_NONE);

			for (vector< Point_<int> > contour : contours)
			{
				Rect region = boundingRect(contour);
				Mat contour_part = boolean_buffer.rowRange(region.y, region.y + region.height).colRange(region.x, region.x + region.width);

				if ((width != 0) && (height != 0))
				{
					size_t part_size = static_cast<size_t>(contour_part.rows) + static_cast<size_t>(contour_part.cols);
					size_t all_size = static_cast<size_t>(boolean_buffer.rows) + static_cast<size_t>(boolean_buffer.cols);
					if ((part_size >= CONTOUR_SIZE_MULTIPLE_CEIL * (width + height)) && (part_size < CONTOUR_SIZE_MULTIPLE_ROOF * all_size))
					{
						Mat contour_resized;
						resize(contour_part, contour_resized, Size(static_cast<int>(width), static_cast<int>(height)));
						imageList.push_back(make_pair(region.x, contour_resized));
					}
					else
					{
						//	DO NOTHING. FILTEWRING THE NOISE.
					}
				}
				else
				{
					imageList.push_back(make_pair(region.x, contour_part));
				}

				sort(imageList.begin(), imageList.end(), comparePairs);
			}
		}
	}

	return imageList.size();
}

uint8_t p206_commonUtil::isJPEGwithEXIF(const string filePath)
{
	const int parseRange = 10;
	char jpegHeader[parseRange];
	int i = 0;
	uint8_t ret = ERRNO_EXIF_OK;
	ifstream binaryFile = ifstream(filePath, ios::binary);

	if (binaryFile.fail())
	{
		cerr << "[" << __func__ << ":" << __LINE__ << "]\tOpening the file failed:\t" << filePath << endl;
		return ERRNO_EXIF_FILE_OPEN_FAILED;
	}

	binaryFile.read(jpegHeader, parseRange);
	binaryFile.close();

#ifdef _DEBUG
	for (i = 0; i != parseRange; ++i)
	{
		cout << "[" << i << "]\t0x" << setw(2) << setfill('0') << hex;
		cout << static_cast<int16_t>(static_cast<uint8_t>(jpegHeader[i])) << dec << endl;
	}
#endif // _DEBUG

	if ((static_cast<uint8_t>(jpegHeader[0]) != static_cast<uint8_t>(0xff)) || 
		(static_cast<uint8_t>(jpegHeader[1]) != static_cast<uint8_t>(0xd8)))
	{
		cerr << "[" << __func__ << ":" << __LINE__ << "]\tThe file is NOT JPEG file:\t" << filePath << endl;
		return ERRNO_EXIF_NOT_JPEG;
	}

	if ((static_cast<uint8_t>(jpegHeader[2]) != static_cast<uint8_t>(0xff)) || 
		(static_cast<uint8_t>(jpegHeader[3]) != static_cast<uint8_t>(0xe1)) || 
		(static_cast<uint8_t>(jpegHeader[6]) != static_cast<uint8_t>(0x45)) || 
		(static_cast<uint8_t>(jpegHeader[7]) != static_cast<uint8_t>(0x78)) || 
		(static_cast<uint8_t>(jpegHeader[8]) != static_cast<uint8_t>(0x69)) || 
		(static_cast<uint8_t>(jpegHeader[9]) != static_cast<uint8_t>(0x66)))
	{
		cerr << "[" << __func__ << ":" << __LINE__ << "]\tThe file DID NOT contain EXIF:\t" << filePath << endl;
		return ERRNO_EXIF_NO_EXIF_IN_JPG;
	}
	return ret;
}
