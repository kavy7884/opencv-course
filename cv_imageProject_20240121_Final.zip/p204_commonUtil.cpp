#include "p204_commonUtil.h"

vector<uint32_t> p204_commonUtil::grayscaleHistogram(const Mat& inputImage)
{
	vector<uint32_t> histoList = vector<uint32_t>(256);
	vector<uint32_t>::iterator it = histoList.begin();

	for (it = histoList.begin(); it != histoList.end(); ++it)
	{
		*it = 0;
	}
	if (inputImage.channels() == 3)
	{
		Mat grayImage;
		cvtColor(inputImage, grayImage, COLOR_BGR2GRAY);
		MatIterator_<uint8_t> it = grayImage.begin<uint8_t>();

		for (it = grayImage.begin<uint8_t>(); it != grayImage.end<uint8_t>(); ++it)
		{
			histoList.at(*it)++;
		}
	}
	return histoList;
}
